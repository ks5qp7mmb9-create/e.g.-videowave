// middleware/auth.js
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev_secret";

export default async function jwtVerify(req, res, next) {
  try {
    const auth = req.headers.authorization || "";
    if (!auth.startsWith("Bearer ")) return res.status(401).json({ error: "missing token" });
    const token = auth.split(" ")[1];
    if (!token) return res.status(401).json({ error: "missing token" });

    const payload = jwt.verify(token, JWT_SECRET);
    // attach minimal user info
    req.user = {
      id: payload.id,
      username: payload.username,
      role: payload.role || "user",
      verified: payload.verified || false
    };
    next();
  } catch (err) {
    console.error("Auth error:", err);
    return res.status(401).json({ error: "invalid or expired token" });
  }
}
