// server.js
// Entry point for the Video Wave backend server

import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";
import rateLimit from "express-rate-limit";
import fs from "fs";
import { fileURLToPath } from "url";

import authRoutes from "./routes/auth.js";
import videoRoutes from "./routes/videos.js";
import ownerRoutes from "./routes/owner.js";
import initOwner from "./utils/initOwner.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/videowave";
const PORT = Number(process.env.PORT || 5000);
const UPLOAD_DIR = process.env.UPLOAD_DIR || "uploads";

// Ensure upload dir exists
const uploadPath = path.resolve(__dirname, UPLOAD_DIR);
if (!fs.existsSync(uploadPath)) {
  fs.mkdirSync(uploadPath, { recursive: true });
}

const app = express();

// Basic security + rate limiting
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false
  })
);

app.use(cors({
  origin: process.env.CLIENT_URL || "*"
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files (videos + thumbnails)
app.use("/media", express.static(uploadPath));

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/videos", videoRoutes);
app.use("/api/owner", ownerRoutes);

// Health
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", service: "Video Wave API" });
});

// Simple minimal frontend for quick testing (not SPA)
app.get("/", (_req, res) => {
  res.redirect("/api/health");
});

// Global error handler
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({
    error: true,
    message: err.message || "Internal server error"
  });
});

async function start() {
  try {
    await mongoose.connect(MONGODB_URI, {
      dbName: "videowave"
    });
    console.log("Connected to MongoDB");

    // Ensure owner seeded
    await initOwner();

    app.listen(PORT, () => {
      console.log(`Video Wave API listening on port ${PORT}`);
      console.log(`Uploads served from /media`);
    });
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}

start();
