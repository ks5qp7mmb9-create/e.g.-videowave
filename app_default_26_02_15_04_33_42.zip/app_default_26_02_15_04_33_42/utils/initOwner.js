// utils/initOwner.js
// Ensures the owner account (videowave / owner2024) exists; run on server start.

import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "../models/user.js";
import bcrypt from "bcrypt";

dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/videowave";

async function initOwner() {
  try {
    // ensure connection if not already connected
    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI, { dbName: "videowave" });
    }
    const existing = await User.findOne({ username: "videowave" });
    if (existing) {
      // ensure owner role and password is correct? We will not reset password if exists.
      if (existing.role !== "owner") {
        existing.role = "owner";
        existing.verified = true;
        await existing.save();
      }
      console.log("Owner account already exists: videowave");
      return;
    }
    const plain = "owner2024";
    const saltRounds = 11;
    const hash = await bcrypt.hash(plain, saltRounds);
    const owner = new User({
      username: "videowave",
      displayName: "Video Wave (Owner)",
      passwordHash: hash,
      verified: true,
      role: "owner"
    });
    await owner.save();
    console.log("Seeded owner account: videowave / owner2024");
  } catch (err) {
    console.error("Failed to seed owner:", err);
    throw err;
  }
}

export default initOwner;

// Allow standalone execution
if (typeof process !== "undefined" && process.argv && process.argv[1] && process.argv[1].endsWith("initOwner.js")) {
  initOwner().then(() => process.exit(0)).catch(() => process.exit(1));
}
