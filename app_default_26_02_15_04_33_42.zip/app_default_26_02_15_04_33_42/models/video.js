// models/video.js
import mongoose from "mongoose";

const Schema = mongoose.Schema;

const VideoSchema = new Schema(
  {
    title: { type: String, default: "" },
    description: { type: String, default: "" },
    filename: { type: String, required: true }, // stored under uploads/
    mimeType: { type: String, required: true },
    size: { type: Number, required: true },
    uploader: { type: Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    thumbnailUrl: { type: String, default: "" },
    createdAt: { type: Date, default: Date.now },
    rejectedReason: { type: String, default: "" }
  },
  { collection: "videos" }
);

export default mongoose.model("Video", VideoSchema);
