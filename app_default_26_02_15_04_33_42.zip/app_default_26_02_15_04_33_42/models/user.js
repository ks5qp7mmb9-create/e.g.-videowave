// models/user.js
import mongoose from "mongoose";

const Schema = mongoose.Schema;

const UserSchema = new Schema(
  {
    username: { type: String, required: true, unique: true, index: true },
    displayName: { type: String, default: "" },
    passwordHash: { type: String, required: true },
    verified: { type: Boolean, default: false }, // verification badge
    followers: { type: Number, default: 0 }, // count only; follow relationships stored separately in Follow collection (or simplistic array)
    following: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now },
    role: { type: String, enum: ["user", "owner"], default: "user" } // owner has extra privileges
  },
  {
    collection: "users"
  }
);

export default mongoose.model("User", UserSchema);
