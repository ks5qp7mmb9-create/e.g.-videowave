// models/follow.js
import mongoose from "mongoose";

const Schema = mongoose.Schema;

/**
 * Simple follow relationship model.
 * This allows us to enforce "no free followers" and track who follows who.
 */
const FollowSchema = new Schema(
  {
    follower: { type: Schema.Types.ObjectId, ref: "User", required: true },
    following: { type: Schema.Types.ObjectId, ref: "User", required: true },
    createdAt: { type: Date, default: Date.now }
  },
  { collection: "follows", indexes: [{ follower: 1, following: 1 }] }
);

FollowSchema.index({ follower: 1, following: 1 }, { unique: true });

export default mongoose.model("Follow", FollowSchema);
