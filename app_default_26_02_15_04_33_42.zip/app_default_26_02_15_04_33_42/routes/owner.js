// routes/owner.js
import express from "express";
import jwtVerify from "../middleware/auth.js";
import Video from "../models/video.js";
import User from "../models/user.js";

const router = express.Router();

// All owner routes protected and must have role owner
router.use(jwtVerify);

function requireOwner(req, res, next) {
  if (!req.user || req.user.role !== "owner") {
    return res.status(403).json({ error: "owner access required" });
  }
  next();
}

router.get("/pending-videos", requireOwner, async (req, res, next) => {
  try {
    const pending = await Video.find({ status: "pending" }).sort({ createdAt: 1 }).limit(200).populate("uploader", "username displayName verified");
    res.json({ ok: true, videos: pending.map(v => ({ id: v._id, title: v.title, description: v.description, filename: v.filename, uploader: v.uploader, size: v.size, thumbnailUrl: v.thumbnailUrl })) });
  } catch (err) {
    next(err);
  }
});

router.post("/approve/:videoId", requireOwner, async (req, res, next) => {
  try {
    const id = req.params.videoId;
    const video = await Video.findById(id);
    if (!video) return res.status(404).json({ error: "video not found" });
    if (video.status === "approved") return res.status(400).json({ error: "already approved" });
    video.status = "approved";
    video.rejectedReason = "";
    await video.save();
    res.json({ ok: true, message: "approved" });
  } catch (err) {
    next(err);
  }
});

router.post("/reject/:videoId", requireOwner, async (req, res, next) => {
  try {
    const id = req.params.videoId;
    const reason = (req.body.reason || "rejected by owner").toString().slice(0, 500);
    const video = await Video.findById(id);
    if (!video) return res.status(404).json({ error: "video not found" });
    video.status = "rejected";
    video.rejectedReason = reason;
    await video.save();
    res.json({ ok: true, message: "rejected" });
  } catch (err) {
    next(err);
  }
});

// Verify a user (gives blue badge)
router.post("/verify-user/:userId", requireOwner, async (req, res, next) => {
  try {
    const uid = req.params.userId;
    const user = await User.findById(uid);
    if (!user) return res.status(404).json({ error: "user not found" });
    if (user.verified) return res.status(400).json({ error: "user already verified" });
    user.verified = true;
    await user.save();
    res.json({ ok: true, message: "user verified", user: { id: user._id, username: user.username, verified: user.verified } });
  } catch (err) {
    next(err);
  }
});

// Owner can list users for moderation
router.get("/users", requireOwner, async (req, res, next) => {
  try {
    const q = (req.query.q || "").toString().trim();
    const filter = {};
    if (q) {
      const regex = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      filter.$or = [{ username: regex }, { displayName: regex }];
    }
    const users = await User.find(filter).limit(200).select("-passwordHash").lean();
    res.json({ ok: true, users });
  } catch (err) {
    next(err);
  }
});

export default router;
