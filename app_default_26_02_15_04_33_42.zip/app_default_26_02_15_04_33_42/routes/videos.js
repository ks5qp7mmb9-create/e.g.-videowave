// routes/videos.js
import express from "express";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import Video from "../models/video.js";
import User from "../models/user.js";
import jwtVerify from "../middleware/auth.js";
import { v4 as uuidv4 } from "uuid";

const router = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const UPLOAD_DIR = process.env.UPLOAD_DIR || "uploads";
const MAX_VIDEO_MB = Number(process.env.MAX_VIDEO_MB || 200);
const MAX_VIDEO_BYTES = MAX_VIDEO_MB * 1024 * 1024;

// multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const d = path.resolve(__dirname, "..", UPLOAD_DIR);
    cb(null, d);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname) || ".mp4";
    const filename = `${Date.now()}_${uuidv4()}${ext}`;
    cb(null, filename);
  }
});

function fileFilter(req, file, cb) {
  // Accept only MP4 / video mimetypes
  const allowed = ["video/mp4", "video/quicktime", "video/x-matroska", "video/webm"];
  if (!allowed.includes(file.mimetype)) {
    return cb(new Error("Only MP4, MOV, MKV, WEBM video types are allowed"));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  limits: { fileSize: MAX_VIDEO_BYTES },
  fileFilter
});

// Publish/upload video (requires auth)
router.post("/upload", jwtVerify, upload.single("video"), async (req, res, next) => {
  try {
    // basic input validation
    const file = req.file;
    const title = (req.body.title || "").toString().slice(0, 200);
    const description = (req.body.description || "").toString().slice(0, 1000);

    if (!file) return res.status(400).json({ error: "video file is required (mp4/mov/mkv/webm)" });

    // Basic bot heuristics:
    // - Reject files that are suspiciously small (<50KB)
    // - Reject filenames containing 'bot' or 'auto' (case-insensitive)
    const suspiciousSize = file.size < 50 * 1024;
    const suspiciousName = /bot|auto|script|test/i.test(file.originalname);

    let status = "pending";
    let rejectedReason = "";

    // Verified users can have videos auto-approved
    const uploader = await User.findById(req.user.id);
    if (!uploader) {
      // remove file if user not found
      try { fs.unlinkSync(file.path); } catch (e) {}
      return res.status(401).json({ error: "uploader not found" });
    }

    if (suspiciousSize || suspiciousName) {
      status = "rejected";
      rejectedReason = suspiciousSize ? "file too small / suspicious" : "filename flagged as bot/auto";
    } else if (uploader.verified || uploader.role === "owner") {
      status = "approved";
    } else {
      status = "pending";
    }

    // Create thumbnail URL (for simplicity, use picsum photo seeded by filename)
    const thumbnailUrl = `https://picsum.photos/seed/${encodeURIComponent(path.basename(file.filename, path.extname(file.filename)) )}/320/180`;

    const v = new Video({
      title,
      description,
      filename: file.filename,
      mimeType: file.mimetype,
      size: file.size,
      uploader: uploader._id,
      status,
      thumbnailUrl,
      rejectedReason
    });

    await v.save();

    res.json({
      ok: true,
      video: {
        id: v._id,
        title: v.title,
        description: v.description,
        filename: v.filename,
        thumbnailUrl: v.thumbnailUrl,
        status: v.status,
        rejectedReason: v.rejectedReason
      }
    });
  } catch (err) {
    // multer file size or fileFilter errors will be channeled here
    next(err);
  }
});

// Get feeds
// FYP: random approved videos (paged)
router.get("/fyp", async (req, res, next) => {
  try {
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 12)));
    // random sample aggregation for variety
    const docs = await Video.aggregate([
      { $match: { status: "approved" } },
      { $sample: { size: limit } },
      {
        $project: {
          title: 1,
          description: 1,
          filename: 1,
          thumbnailUrl: 1,
          uploader: 1,
          views: 1,
          likes: 1,
          createdAt: 1
        }
      }
    ]);
    res.json({ ok: true, videos: docs.map(d => ({ ...d, mediaUrl: `/media/${d.filename}` })) });
  } catch (err) {
    next(err);
  }
});

// Following feed: requires auth; returns approved videos from people you follow ordered by newest
import Follow from "../models/follow.js";
router.get("/following", jwtVerify, async (req, res, next) => {
  try {
    const userId = req.user.id;
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 20)));
    const follows = await Follow.find({ follower: userId }).select("following -_id").lean();
    const followingIds = follows.map(f => f.following);
    if (followingIds.length === 0) return res.json({ ok: true, videos: [] });
    const videos = await Video.find({ uploader: { $in: followingIds }, status: "approved" })
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();
    res.json({ ok: true, videos: videos.map(v => ({ ...v, mediaUrl: `/media/${v.filename}` })) });
  } catch (err) {
    next(err);
  }
});

// Get single video and increment views (safe increment)
router.get("/:id", async (req, res, next) => {
  try {
    const id = req.params.id;
    const video = await Video.findByIdAndUpdate(id, { $inc: { views: 1 } }, { new: true }).lean();
    if (!video) return res.status(404).json({ error: "video not found" });
    if (video.status !== "approved") {
      return res.status(403).json({ error: "video not accessible" });
    }
    res.json({ ok: true, video: { ...video, mediaUrl: `/media/${video.filename}` } });
  } catch (err) {
    next(err);
  }
});

// Like video
router.post("/:id/like", jwtVerify, async (req, res, next) => {
  try {
    const id = req.params.id;
    const v = await Video.findByIdAndUpdate(id, { $inc: { likes: 1 } }, { new: true });
    if (!v) return res.status(404).json({ error: "video not found" });
    if (v.status !== "approved") return res.status(403).json({ error: "video not accessible" });
    res.json({ ok: true, likes: v.likes });
  } catch (err) {
    next(err);
  }
});

// Search videos by title/description (approved only)
router.get("/", async (req, res, next) => {
  try {
    const q = (req.query.q || "").toString().trim();
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 20)));
    if (!q) return res.status(400).json({ error: "query param q is required" });
    const regex = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    const results = await Video.find({ status: "approved", $or: [{ title: regex }, { description: regex }] })
      .sort({ createdAt: -1 })
      .limit(limit)
      .lean();
    res.json({ ok: true, videos: results.map(v => ({ ...v, mediaUrl: `/media/${v.filename}` })) });
  } catch (err) {
    next(err);
  }
});

export default router;
